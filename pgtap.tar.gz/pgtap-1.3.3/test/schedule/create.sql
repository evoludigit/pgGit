\unset ECHO
\i test/psql.sql
CREATE EXTENSION pgtap;
