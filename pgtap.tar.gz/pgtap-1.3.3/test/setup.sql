\i test/psql.sql

BEGIN;
-- \i sql/pgtap.sql
