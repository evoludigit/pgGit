# Phase 7 Constraint Violation Fix Plan

**Status**: Plan Mode - Awaiting User Approval
**Date**: December 29, 2025
**Objective**: Fix 5 bootstrap constraint violations to make Phase 7 production-ready
**Estimated Work**: 15-20 minutes
**Impact**: Increase Phase 7 test pass rate from 33/74 (44.6%) to ~95%+

---

## Problem Summary

Phase 7 performance monitoring schema exists but has **5 critical constraint violations** in bootstrap data that prevent schema loading:

| Issue | Type | Severity | Impact |
|-------|------|----------|--------|
| Duration consistency (RANDOM mismatch) | Data | CRITICAL | Inserts fail |
| Time order violation (end_time < start_time) | Data | CRITICAL | Data integrity |
| Period_start mismatch (old metrics, new period) | Data | HIGH | Analytics broken |
| Numeric precision inconsistency | Data | MEDIUM | Rounding errors |
| Foreign key refs (already fixed) | Schema | NONE | ✅ Already OK |

**Root Cause**: All 5 INSERT statements use independent `RANDOM()` calls for:
1. `duration_microseconds = (2000 + RANDOM())`
2. `duration_ms = ((2000 + RANDOM()) / 1000)` ← DIFFERENT random value!
3. `end_time = start_time + ((2000 + RANDOM()) microseconds)` ← ANOTHER random value!
4. `period_start = DATE_TRUNC('day', NOW())` ← Always today, but metrics are 7 days old

---

## Implementation Plan

### Phase 7 Fix Phase 1: Duration Consistency (BLOCKER)

**File**: `sql/v1.0.0/phase7_performance_bootstrap.sql`
**Lines Affected**: 115-116, 133-134, 151-152, 169-170, 187-188 (5 INSERT statements)
**Complexity**: 🟢 Simple (refactor to calculate duration once, use twice)

**Current Code Pattern** (WRONG):
```sql
INSERT INTO pggit.performance_metrics
    (operation_type, operation_name, duration_microseconds, duration_ms, ...)
SELECT
    'commit',
    'commit_' || i::TEXT,
    (2000 + (RANDOM() * 5000))::BIGINT,              -- RANDOM VALUE #1
    ((2000 + (RANDOM() * 5000))::BIGINT)::NUMERIC / 1000,  -- RANDOM VALUE #2 (DIFFERENT!)
    ...
```

**Why It Fails**:
- Constraint check: `chk_duration_consistency: duration_ms = duration_microseconds / 1000`
- First RANDOM() → 3500 microseconds → duration_ms should be 3.5
- Second RANDOM() → 4200 microseconds → duration_ms calculated as 4.2
- Check: `4.2 = 3500 / 1000 = 3.5` → FALSE, INSERT fails

**Fix Strategy**: Use PL/pgSQL to calculate duration once

**Fixed Pattern**:
```sql
INSERT INTO pggit.performance_metrics
    (operation_type, operation_name, duration_microseconds, duration_ms, ...)
SELECT
    'commit',
    'commit_' || i::TEXT,
    dur_us,                              -- Use stored value
    dur_us::NUMERIC / 1000,              -- Derive from stored value
    ...
FROM (
    SELECT
        (2000 + (RANDOM() * 5000))::BIGINT AS dur_us  -- Calculate ONCE
) sub
CROSS JOIN generate_series(1, 20) AS t(i);
```

**Alternative Pattern** (with CTE):
```sql
WITH durations AS (
    SELECT
        i,
        (2000 + (RANDOM() * 5000))::BIGINT AS duration_microseconds
    FROM generate_series(1, 20) AS t(i)
)
INSERT INTO pggit.performance_metrics
    (operation_type, operation_name, duration_microseconds, duration_ms, ...)
SELECT
    'commit',
    'commit_' || i::TEXT,
    duration_microseconds,
    (duration_microseconds::NUMERIC / 1000)::NUMERIC(10,3),
    ...
FROM durations;
```

**Recommendation**: Use CTE pattern (more readable, maintainable)

---

### Phase 7 Fix Phase 2: Time Order Consistency

**File**: `sql/v1.0.0/phase7_performance_bootstrap.sql`
**Lines Affected**: 117-119, 135-137, 153-155, 171-173, 189-191 (5 INSERT statements)
**Complexity**: 🟢 Simple (refactor to use duration variable for end_time calculation)

**Current Code Pattern** (PROBLEMATIC):
```sql
start_time := CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL,
end_time   := CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL +
    ((((2000 + (RANDOM() * 5000))::BIGINT) || ' microseconds')::INTERVAL),
```

**Issue**: Another independent RANDOM() call generates a different duration for end_time
- Calculation: `end_time = start_time + duration_from_DIFFERENT_RANDOM()`
- Can produce: `end_time < start_time` if new random is smaller
- Violates: `chk_time_order: start_time < end_time`

**Fix**: Use the same duration variable calculated in Phase 1

**Fixed Pattern**:
```sql
start_time := CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL,
end_time   := CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL +
    (duration_microseconds || ' microseconds')::INTERVAL,  -- USE STORED VALUE
```

---

### Phase 7 Fix Phase 3: Period_start Consistency

**File**: `sql/v1.0.0/phase7_performance_bootstrap.sql`
**Lines Affected**: 122, 140, 158, 176, 194 (5 INSERT statements)
**Complexity**: 🟢 Simple (fix period_start calculation)

**Current Code Pattern** (WRONG):
```sql
period_start := DATE_TRUNC('day', CURRENT_TIMESTAMP),  -- Always TODAY
-- But metrics are from: CURRENT_TIMESTAMP - INTERVAL '7 days'
```

**Issue**: Query logic expects `period_start` to match metric timestamp
```sql
WHERE pm.period_start >= CURRENT_DATE - (p_lookback_days || ' days')::INTERVAL
-- Won't find 7-day-old metrics because period_start != their date
```

**Fix**: Calculate period_start from actual metric timestamp

**Fixed Pattern**:
```sql
period_start := DATE_TRUNC('day', CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL)
-- Period matches the metric's actual timestamp
```

---

### Phase 7 Fix Phase 4: Numeric Precision

**File**: `sql/v1.0.0/phase7_performance_bootstrap.sql`
**Lines Affected**: Same 5 INSERT statements
**Complexity**: 🟢 Simple (explicit type casting)

**Current Code**:
```sql
duration_ms := ((2000 + (RANDOM() * 5000))::BIGINT)::NUMERIC / 1000
-- May produce: 5.743 or 5.7430000 (inconsistent precision)
```

**Schema Definition**:
```sql
duration_ms NUMERIC(10,3)  -- Exactly 3 decimal places
```

**Fix**: Explicit type casting in the CTE

```sql
WITH durations AS (
    SELECT
        i,
        (2000 + (RANDOM() * 5000))::BIGINT AS duration_microseconds
    FROM generate_series(1, 20) AS t(i)
)
SELECT
    ...
    (duration_microseconds::NUMERIC(10,3) / 1000) AS duration_ms,
    ...
```

---

## Detailed Implementation Steps

### Step 1: Refactor First INSERT (commit operations) - Lines 109-124

**Before**:
```sql
INSERT INTO pggit.performance_metrics
    (operation_type, operation_name, duration_microseconds, duration_ms,
     start_time, end_time, user_name, session_id, period_start, operation_metadata)
SELECT
    'commit',
    'commit_' || i::TEXT,
    (2000 + (RANDOM() * 5000))::BIGINT,
    ((2000 + (RANDOM() * 5000))::BIGINT)::NUMERIC / 1000,
    CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL,
    CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL +
        ((((2000 + (RANDOM() * 5000))::BIGINT) || ' microseconds')::INTERVAL),
    'bootstrap_user',
    'bootstrap_session_commit',
    DATE_TRUNC('day', CURRENT_TIMESTAMP),
    jsonb_build_object('ddl_statements', 5, 'dml_statements', 0)
FROM generate_series(1, 20) AS t(i);
```

**After**:
```sql
WITH commit_durations AS (
    SELECT
        i,
        (2000 + (RANDOM() * 5000))::BIGINT AS duration_microseconds
    FROM generate_series(1, 20) AS t(i)
)
INSERT INTO pggit.performance_metrics
    (operation_type, operation_name, duration_microseconds, duration_ms,
     start_time, end_time, user_name, session_id, period_start, operation_metadata)
SELECT
    'commit',
    'commit_' || i::TEXT,
    duration_microseconds,
    (duration_microseconds::NUMERIC(10,3) / 1000),
    CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL,
    CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL +
        (duration_microseconds || ' microseconds')::INTERVAL,
    'bootstrap_user',
    'bootstrap_session_commit',
    DATE_TRUNC('day', CURRENT_TIMESTAMP - INTERVAL '7 days' + (i || ' minutes')::INTERVAL),
    jsonb_build_object('ddl_statements', 5, 'dml_statements', 0)
FROM commit_durations;
```

**Changes**:
1. ✅ Wrapped in CTE to calculate duration once
2. ✅ Reuse `duration_microseconds` for both columns
3. ✅ Derive `duration_ms` from `duration_microseconds`
4. ✅ Use stored `duration_microseconds` for end_time calculation
5. ✅ Fix `period_start` to match metric timestamp

### Step 2-5: Apply Same Pattern to Remaining 4 INSERTs

Repeat Step 1 pattern for:
- **Step 2**: merge_branches (lines 127-142) - Use CTE named `merge_durations`
- **Step 3**: get_history (lines 145-160) - Use CTE named `history_durations`
- **Step 4**: branch_create (lines 163-178) - Use CTE named `branch_durations`
- **Step 5**: rollback_commit (lines 181-196) - Use CTE named `rollback_durations`

Each follows identical pattern with different:
- Duration range (commit: 2-7ms, merge: 50-100ms, etc.)
- CTE name
- generate_series count (20, 15, 25, 12, 10 respectively)

---

## Verification Strategy

### Pre-Fix Verification
```bash
# Test 1: Current state shows failures
uv run pytest tests/integration/ -q --tb=short | grep phase7

# Expected: 33 passed, 41 failed
```

### Post-Fix Verification
```bash
# Test 1: Schema loads without constraint violations
psql -h localhost -U postgres -d pggit -f sql/v1.0.0/phase7_performance_bootstrap.sql
# Expected: All INSERTs succeed with no constraint violations

# Test 2: Run integration tests
uv run pytest tests/integration/ -q --tb=short | grep phase7
# Expected: 70+ tests passing (up from 33)

# Test 3: Verify constraint satisfaction
psql -h localhost -U postgres -d pggit -c "
SELECT
  COUNT(*) as total_metrics,
  SUM(CASE WHEN duration_ms = duration_microseconds::NUMERIC / 1000 THEN 1 ELSE 0 END) as valid_durations,
  SUM(CASE WHEN end_time > start_time THEN 1 ELSE 0 END) as valid_times
FROM pggit.performance_metrics;
"
# Expected: All counts match total_metrics (all valid)
```

---

## Risk Assessment

### Low Risk Reasons
1. **Data is bootstrap test data** - Can be safely replaced
2. **All changes are in one file** - `phase7_performance_bootstrap.sql`
3. **Pattern is simple** - Just wrap in CTE, reuse values
4. **No schema changes** - Constraints stay as-is
5. **No application code changes** - Pure SQL migration

### Validation Checklist
- [ ] All 5 INSERT statements follow CTE pattern
- [ ] Each duration variable used exactly twice (duration_microseconds and in end_time)
- [ ] All period_start values match their timestamp range
- [ ] Numeric casting to NUMERIC(10,3) applied
- [ ] Duration ranges preserved (commit 2-7ms, merge 50-100ms, etc.)
- [ ] User/session names consistent with expectations
- [ ] JSONB metadata preserved

---

## Alternative Approach (Not Recommended)

Instead of using CTEs, could disable constraints, insert, then enable:
```sql
ALTER TABLE pggit.performance_metrics DISABLE TRIGGER ALL;
-- INSERT problematic data
ALTER TABLE pggit.performance_metrics ENABLE TRIGGER ALL;
```

**Why Not**:
- Masks root problem instead of fixing it
- Data would still be invalid
- Queries would produce wrong results
- No improvement to analytics functionality

---

## Decision Outcomes

### Option A: Fix Phase 7 Now (Recommended)
- **Effort**: 15-20 minutes
- **Benefit**: Move Phase 7 from 44.6% → 95%+ passing
- **Cost**: Minimal (simple SQL refactoring)
- **Impact on v0.1.0**: None (Phase 7 deferred anyway)
- **Impact on v0.2.0**: Enables Phase 7 monitoring features immediately

### Option B: Keep Deferred to v0.2.0
- **Effort**: 0 minutes now
- **Benefit**: Focus on other priorities (Docker, docs)
- **Cost**: Phase 7 work pushed to next sprint
- **Impact on v0.1.0**: None (as intended)

---

## Recommendation

✅ **Proceed with Fix Phase 7 Now**

**Rationale**:
1. All work is simple, low-risk SQL changes
2. Fixes are isolated to one file (phase7_performance_bootstrap.sql)
3. Unblocks Phase 7 testing and analytics features
4. Takes only 15-20 minutes
5. No impact on v0.1.0 (Phase 7 already deferred)
6. Readies system for v0.2.0 monitoring features
7. Cleans up technical debt before it accumulates

---

## Next Steps (After Approval)

1. ✏️ **Implement**: Fix all 5 INSERT statements in phase7_performance_bootstrap.sql
2. 🧪 **Test**: Run Phase 7 tests and verify 95%+ pass rate
3. 📝 **Document**: Update PHASE_7_FIX_PLAN.md with completion status
4. 💾 **Commit**: Create commit "fix(phase7): Resolve constraint violations in performance bootstrap data"
5. 🔄 **Next**: Move to Phase 11 or Docker containerization

---

**Status**: Awaiting user approval to proceed with implementation
**Decision Deadline**: User confirmation to start fixes
