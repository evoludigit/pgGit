# Technical Decomposition: Detailed Phase-by-Phase Implementation

## Overview

This document breaks down each moon shot phase into concrete technical tasks, database schema changes, function implementations, and deliverables.

---

# PHASE 1: SCHEMA VCS FOUNDATION (Months 1-3)

## Phase 1 Target: Git-like schema version control for dev teams

**Success = developers can:**
```sql
SELECT pggit.create_branch('feature/new-table');
-- develop schema
SELECT pggit.merge('main');
-- conflicts resolved, merged back
```

---

## Phase 1a: v0.1.4 Stabilization (Week 1-2)

### Task 1.1: Remove Aspirational Tests

**Current State:**
- `tests/test-data-branching.sql` has 6 tests
- Tests 1 = core (passes)
- Tests 2, 5, 6 = aspirational (incomplete)

**Action:**

```sql
-- File: tests/test-data-branching.sql

-- BEFORE:
-- 6 tests all running

-- AFTER:
-- Keep: Test 1 (basic data branching)
-- Skip with comment:

-- Test 2: Copy-on-Write Efficiency
--   Status: PHASE 2+ (temporal queries)
--   Reason: Requires timestamp-based routing, not core to v0.1
--   TODO: Implement in Phase 2 when temporal layer added

-- Test 5: Temporal Branching
--   Status: PHASE 2+ (temporal layer)
--   Reason: Requires point-in-time snapshots
--   TODO: Implement in Phase 2 when temporal layer added

-- Test 6: Branch Storage Optimization
--   Status: PHASE 4+ (optimization layer)
--   Reason: Requires CoW implementation and analysis
--   TODO: Implement in Phase 4 when optimization layer added
```

**SQL Changes:**

```sql
-- In tests/test-data-branching.sql, around line 200 (example):

DO $$ BEGIN
  -- Test 1: Basic data branching (ENABLED)
  PERFORM test_basic_data_branching();

  -- Test 2: Copy-on-Write Efficiency (DISABLED - Phase 2+)
  -- PERFORM test_cow_efficiency();  -- TODO: Phase 2

  -- Test 5: Temporal Branching (DISABLED - Phase 2+)
  -- PERFORM test_temporal_branching();  -- TODO: Phase 2

  -- Test 6: Storage Optimization (DISABLED - Phase 4+)
  -- PERFORM test_storage_optimization();  -- TODO: Phase 4
END $$;
```

**Verification:**
```bash
make test
# Expected: 12/12 tests pass (or 1/1 if only core test runs)
```

---

### Task 1.2: Write ARCHITECTURE.md

**Create new file:** `docs/ARCHITECTURE.md`

**Content structure:**

```markdown
# pgGit Architecture

## 1. Core Principle: View-Based Routing

### Problem Solved
PostgreSQL's PL/pgSQL plan caching resolves table OIDs at compile time, not runtime.
Traditional search_path manipulation defeats branch switching within cached plans.

### Solution: Dynamic SQL Routing
Replace table access with VIEW routing via EXECUTE statements.

### Diagram
[ASCII diagram of routing layer]

## 2. Data Model

### Schema Structure
- `pggit` schema: Metadata tables
  - `branches`: Branch definitions
  - `branch_history`: Audit of branch operations
  - `settings`: Configuration

- `pggit_base` schema: Main tables (original)
  - All user tables mirrored here
  - Audit triggers capture changes
  - Reference point for branches

- `pggit_branch_*` schemas: Branch-specific data
  - One schema per branch
  - Contains working copies of tables
  - Isolated from other branches

- `public` schema: User-facing VIEWs
  - Views replace original tables
  - Route queries to correct branch
  - INSTEAD OF triggers handle writes

### Table Definitions

**pggit.branches:**
```sql
CREATE TABLE pggit.branches (
  id uuid PRIMARY KEY,
  name text NOT NULL UNIQUE,
  parent_id uuid REFERENCES pggit.branches(id),
  created_at timestamp NOT NULL,
  created_by text NOT NULL,
  created_from_branch text NOT NULL,
  status text CHECK (status IN ('active', 'merged', 'deleted')),

  -- Phase 2+ ready (not used in Phase 1)
  extension_context jsonb  -- For temporal, audit, etc. context
);
```

**pggit.branch_history:**
```sql
CREATE TABLE pggit.branch_history (
  id uuid PRIMARY KEY,
  branch_id uuid REFERENCES pggit.branches(id),
  operation text,  -- 'created', 'merged', 'switched'
  timestamp timestamp NOT NULL,
  details jsonb
);
```

## 3. Routing Mechanism

### View Creation
For each table in user schema, create:

```sql
-- Example: user has table 'products'
-- Original location: public.products

-- Move to base:
-- CREATE TABLE pggit_base.products AS SELECT * FROM public.products;

-- Replace with view:
-- CREATE VIEW public.products AS ...route_products()...

-- Route function:
CREATE FUNCTION route_products()
RETURNS TABLE (same columns as products)
AS $$
BEGIN
  RETURN QUERY EXECUTE format(
    'SELECT * FROM %I.products',
    'pggit_' || coalesce(current_setting('pggit.current_branch'), 'base')
  );
END
$$ LANGUAGE plpgsql;
```

### Context Setting
```sql
-- Developer switches branches:
SET pggit.current_branch = 'feature/new-table';
SELECT * FROM products;  -- Routes to pggit_feature_new_table.products

SET pggit.current_branch = 'main';
SELECT * FROM products;  -- Routes to pggit_base.products
```

## 4. Operations

### v0.1: Basic Branching
- `create_branch(branch_name, parent_branch)`
- `switch_branch(branch_name)`
- `list_branches()`
- `delete_branch(branch_name)`

### v0.2: Merge Operations (NEW)
- `merge(source_branch, target_branch)`
- `detect_conflicts(source, target)`
- `resolve_conflict(table_name, conflict_data)`

### v0.3: Diffing (NEW)
- `schema_diff(branch_a, branch_b)`
- `data_diff(table_name, branch_a, branch_b)`
- `generate_patch(branch_a, branch_b)`

## 5. Extensibility Points (for Phase 2+)

### Context System
```
Phase 1: context = { branch: 'X' }
Phase 2: context = { branch: 'X', timestamp: 'T' }
Phase 3: context = { branch: 'X', timestamp: 'T', audit_version: 'V' }
Phase 4: context = { branch: 'X', timestamp: 'T', audit_version: 'V',
                     optimization: 'CoW' }
```

### Extension Points
- `pggit_temporal` schema (Phase 2)
- `pggit_audit_compliance` schema (Phase 3)
- `pggit_optimize` schema (Phase 4)

### Plugin System (Phase 5+)
- Custom context handlers
- Custom routing rules
- Custom storage backends

## 6. Performance Characteristics (Phase 1)

### Operations Costs
- `create_branch()`: O(n) where n = number of tables
  - Reason: Must create schema, copy table definitions

- `switch_branch()`: O(1)
  - Reason: Just changes setting

- `merge()`: O(n * m) where n = tables, m = rows
  - Reason: Must copy changed rows

- `schema_diff()`: O(n) where n = number of tables
  - Reason: Compare schema definitions

### Query Performance
- Query through view: ~5-10% overhead
  - Reason: One EXECUTE call per query
  - Mitigation: Prepared statements in application layer

- SELECT queries: Same performance as direct table access
- INSERT/UPDATE/DELETE: 10-20% overhead (view routing)

## 7. Limitations (Phase 1)

What pgGit does NOT do (yet):
- ❌ Time-travel queries (Phase 2)
- ❌ Immutable audit logs (Phase 3)
- ❌ Storage optimization (Phase 4)
- ❌ Multi-database federation
- ❌ Distributed branching

## 8. Future Architecture (Phases 2-6)

[Describe placeholder for temporal, audit, optimize layers]
```

**File location:** `docs/ARCHITECTURE.md`

---

### Task 1.3: Update README.md

**Changes to `README.md`:**

```markdown
# pgGit: The PostgreSQL Extensibility Platform

**Version:** 0.1.4 (Phase 1: Schema VCS)

## What Is pgGit?

pgGit is a comprehensive platform for managing PostgreSQL database evolution.

### Current Phase (v0.1-v1.0): Schema VCS
Git-like version control for database schemas. Branch, merge, diff, and revert schema changes with confidence.

### Future Phases
- **Phase 2 (v1.1+):** Time-travel queries for analytics
- **Phase 3 (v1.6+):** Compliance & audit for regulated industries
- **Phase 4 (v2.0+):** Performance optimization
- **Phase 5 (v2.5+):** Business layer (pgGit Cloud, integrations)
- **Phase 6 (v3.0+):** Expansion products (pgTime, pgAudit, pgPerf)

## Quick Start

```sql
-- Install pgGit
CREATE EXTENSION pggit CASCADE;

-- Create a branch
SELECT pggit.create_branch('feature/new-table', 'main');
SELECT pggit.switch_branch('feature/new-table');

-- Develop your schema
CREATE TABLE new_table (id uuid PRIMARY KEY);
ALTER TABLE products ADD COLUMN category text;

-- Merge back to main
SELECT pggit.switch_branch('main');
SELECT pggit.merge('feature/new-table', 'main');
```

## Roadmap

| Version | Release | Focus | Milestone |
|---------|---------|-------|-----------|
| 0.1.4 | Feb 2026 | Schema VCS foundation | Stable |
| 0.2.0 | Apr 2026 | Merge operations | Git-like |
| 0.3.0 | Jun 2026 | Schema diffing | Full VCS |
| 1.0.0 | Jul 2026 | Production ready | Market validation |
| 1.1+ | Q3 2026 | Temporal queries (Phase 2) | Analytics |
| 2.0+ | Q4 2026 | Compliance & audit (Phase 3) | Enterprise |

## Architecture

See [ARCHITECTURE.md](docs/ARCHITECTURE.md) for detailed design.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) and [GOVERNANCE.md](GOVERNANCE.md).
```

---

### Task 1.4: Create GOVERNANCE.md

**Create new file:** `GOVERNANCE.md`

```markdown
# pgGit Governance

## Vision
Build the PostgreSQL extensibility platform serving development teams, analytics teams, compliance teams, and DBAs through disciplined phased expansion.

## Decision-Making Structure

### Leadership
- **Project Owner (evoludigit)**: Vision, roadmap, strategic decisions
- **Technical Architect (stephengibson12)**: Core implementation, technical decisions
- **Contributors**: Feature implementation, bug fixes, documentation

### Decision Levels

**Strategic (Project Owner decides)**
- Which phase to prioritize next
- Major architectural changes
- Public messaging and positioning
- Roadmap adjustments

**Technical (Technical Architect decides)**
- Implementation approaches
- Code structure and organization
- Performance optimizations
- Testing strategy

**Tactical (Contributors can decide)**
- Specific bug fixes
- Documentation improvements
- Code refactoring
- Test additions for current phase

### Approval Process
- Phase 1 features: TechArch approval required
- Phase 2+ features: Rejected (go into future roadmap)
- Bug fixes: TechArch approval
- Documentation: Community can contribute

## Phase System

Each phase is:
- **Focused**: One clear goal
- **Independent**: Builds on previous without breaking changes
- **Validated**: Market feedback before proceeding
- **Time-bounded**: Months 1-3, 4-6, etc.

## Contributing to pgGit

### Phase 1 (Current)
We are building **Schema VCS for development teams**.

**Accepted PRs:**
- Bug fixes to existing functionality
- Performance improvements
- Documentation improvements
- Tests for schema VCS features

**Rejected PRs:**
- Temporal query features (Phase 2+)
- Compliance features (Phase 3+)
- Optimization features (Phase 4+)

Rationale: Early feature focus is critical to market validation.

### Future Phases
As we progress, contribution guidelines evolve.
Roadmap is published and can be discussed.

## Communication

- Monthly updates on r/PostgreSQL
- GitHub issues for feedback and requests
- GitHub discussions for design decisions
- Roadmap document published and pinned

## Contributor Path

Consistent contributors with quality work may be invited to:
- Become maintainers for specific modules
- Lead Phase 2+ implementation
- Co-author technical decisions

---
```

---

### Task 1.5: Create ROADMAP.md

**Create new file:** `ROADMAP.md`

```markdown
# pgGit 18-Month Roadmap

## Executive Summary
pgGit is a phased expansion from schema VCS → temporal queries → compliance → optimization → business layer → expansion products.

Each phase is ~3 months, market-validated before proceeding to next.

## Phase 1: Schema VCS Foundation (Months 1-3)

**Market Target:** Development teams
**Success Criteria:** 100+ production users, 1500+ GitHub stars

### v0.1.4 (February 2026)
- Stable foundation
- Tests clean
- Documentation complete
- Community engaged

**Deliverables:**
- Merge PR #6, #7, #8, #9
- Remove aspirational tests
- Write ARCHITECTURE.md
- Update README, create GOVERNANCE.md, ROADMAP.md
- Release stable v0.1.4

**Success Metric:** 500+ GitHub stars

### v0.2 (April 2026)
- Merge operations with conflict detection
- Manual conflict resolution
- Merge history

**Technical Work:**
- New file: `sql/052_merge_operations.sql`
- New file: `sql/053_conflict_detection.sql`
- New tests: `tests/test-schema-merge.sql`
- Function: `pggit.merge(source_branch, target_branch, strategy)`
- Function: `pggit.detect_conflicts(table_name, source, target)`
- Function: `pggit.resolve_conflict(table_name, ...)`

**Success Metric:** 20+ production users, 750+ GitHub stars

### v0.3 (June 2026)
- Schema diffing between branches
- SQL patch generation
- Human-readable diffs

**Technical Work:**
- New file: `sql/054_schema_diffing.sql`
- Function: `pggit.schema_diff(branch_a, branch_b) RETURNS TABLE`
- Function: `pggit.data_diff(table_name, branch_a, branch_b) RETURNS TABLE`
- Function: `pggit.generate_patch(branch_a, branch_b) RETURNS text`
- Script: `scripts/generate_schema_patch.sql`

**Success Metric:** 50+ production users

### v1.0 (July 2026)
- Production-ready
- Team collaboration features
- CI/CD integration examples
- Web dashboard (beta)

**Technical Work:**
- Function: `pggit.get_branch_history(branch_name) RETURNS TABLE`
- Function: `pggit.who_changed(table_name) RETURNS TABLE` (user tracking)
- Examples: `.github/workflows/pgGit-deploy.yml`
- Examples: `docs/guides/ci-cd-integration.md`
- Web UI: Basic branch management (Vue.js, PostgreSQL JSON API)

**Success Metric:** 100+ production users, 1500+ GitHub stars, acquisition interest

**Decision Point:** Is demand for Phase 2 real? Proceed to temporal queries?

---

## Phase 2: Temporal Queries (Months 4-6)

**Market Target:** Analytics teams (ADD to dev teams, don't replace)
**Non-Breaking:** All Phase 1 features still work

### Architecture Decision (Phase 1 end)
Extend context system:
```
Phase 1: context = { branch: 'X' }
Phase 2: context = { branch: 'X', timestamp: 'T' }
```

### v1.1 (May 2026)
- Point-in-time query capability
- Timestamp routing layer
- Basic time-travel semantics

**Technical Work:**
- New schema: `pggit_temporal`
- New file: `sql/055_temporal_routing.sql`
- New table: `pggit.versions` (snapshot tracking)
- Function: `pggit.query_at_time(table_name, timestamp)`
- Function: `pggit.snapshot_at_time(branch_name, timestamp)`

### v1.2 (June 2026)
- Full temporal branching
- Historical data analysis
- Temporal query examples

**Technical Work:**
- Function: `pggit.create_temporal_branch(source_branch, base_time, branch_name)`
- Function: `pggit.query_between_times(table_name, t1, t2)`
- Examples: `docs/guides/temporal-queries.md`
- Tests: `tests/test-temporal-queries.sql`

### Decision Point
Is Phase 3 (compliance) the right next step? Or pivot based on feedback?

---

## Phase 3: Compliance & Audit (Months 7-9)

**Market Target:** Regulated industries (ADD analytics and dev markets)
**Non-Breaking:** All Phase 1-2 features still work

### Architecture
New independent audit layer:
- Immutable storage
- Compliance reporting
- Access control integration

### v1.6 (July 2026)
- Immutable audit logs
- Basic compliance reports
- Access control integration

**Technical Work:**
- New schema: `pggit_audit_compliance`
- New file: `sql/056_immutable_audit.sql`
- New file: `sql/057_compliance_reporting.sql`
- Function: `pggit.generate_compliance_report(table_name, date_range)`
- Function: `pggit.audit_trail(operation_type, date_range) RETURNS TABLE`

### v1.7-v1.8 (Aug-Sep 2026)
- Regulatory templates (SOX, HIPAA, GDPR)
- Change approval workflows
- Data lineage tracking

---

## Phase 4: Optimization (Months 10-12)

**Market Target:** Everyone (transparent improvement)
**Non-Breaking:** All Phase 1-3 features still work, just faster

### Architecture
Optimization layer is transparent:
- Same queries produce same results
- But storage is 10x smaller
- And queries are faster

### v2.0 (Oct-Dec 2026)
- Copy-on-write deduplication
- Storage compression
- Query optimization

**Technical Work:**
- New schema: `pggit_optimize`
- New file: `sql/058_cow_deduplication.sql`
- New table: `pggit_optimize.block_references` (CoW tracking)
- Function: `pggit.analyze_storage()` (show compression savings)

---

## Phase 5: Business Layer (Months 13-15)

**Goal:** Monetization and ecosystem growth

### v2.5 (Jan-Mar 2027)
- pgGit Cloud managed hosting
- Team dashboard
- GitHub/GitLab integration
- IDE plugins (VS Code, DataGrip, DBeaver)

**Technical Work:**
- Web application: `pgGit.cloud` (Node.js/Next.js)
- API: RESTful endpoints for branch management
- Integrations: GitHub Actions, GitLab CI
- IDE plugins: VS Code extension repository

### Business Model
- **Free tier:** 1 database, basic schema VCS
- **Pro:** $50/month, unlimited databases, team features
- **Enterprise:** Custom pricing, all features + support

---

## Phase 6: Expansion Products (Months 16-18)

**Goal:** Category leadership across multiple markets

### Create Focused Products
Each is a separate brand/marketing, but shares pgGit foundation:

- **pgTime:** Temporal database for analytics teams
- **pgAudit:** Compliance platform for regulated industries
- **pgPerf:** Performance and optimization for DBAs

All coexist on same pgGit foundation, zero conflicts.

---

## Decision Points & Validation Gates

### After v0.1.4 (Feb)
**Question:** Is community engagement real?
- If YES (500+ stars, active issues): Continue to v0.2
- If NO: Reassess market fit

### After v0.2 (April)
**Question:** Are dev teams actually merging schemas?
- If YES (20+ users, merge usage): Continue to v0.3
- If NO: Focus on what's needed instead

### After v1.0 (July)
**Question:** Do we have market validation for Phase 2?
- If YES (100+ users, demand for temporal): Start Phase 2
- If NO: Stay in Phase 1, improve features

### After Phase 1 Complete
**Major Decision:** Continue to Phase 2+?
- If YES: Execute Phases 2-6 as planned
- If NO: Stabilize Phase 1, consider acquisition

---

## Risk Mitigation

### Risk: Feature Creep in Phase 1
**Mitigation:** Strict PR review: "Is this schema VCS? Yes/No?"

### Risk: Developer Community Doesn't Use It
**Mitigation:** Decision gate after v0.2, pivot if needed

### Risk: Phases don't compose without breaking changes
**Mitigation:** Architecture designed for extensibility, tested with v0.2+

### Risk: Team burnout from 18-month sprint
**Mitigation:** Team grows incrementally, each phase hires specialists

---
```

---

### Task 1.6: Update/Create Key Files for Commit

**Checklist for v0.1.4:**

- [x] `docs/ARCHITECTURE.md` - Created
- [x] `GOVERNANCE.md` - Created
- [x] `ROADMAP.md` - Created
- [ ] `README.md` - Updated with moon shot vision
- [ ] `tests/test-data-branching.sql` - Remove Tests 2, 5, 6
- [ ] `CHANGELOG.md` - Document v0.1.4 release

---

## Phase 1b: v0.2 Merge Operations (Weeks 5-8)

### Task 2.1: Create Merge Operations Foundation

**New file:** `sql/052_merge_operations.sql`

```sql
-- File: sql/052_merge_operations.sql
-- Purpose: Core merge functionality for schema VCS
-- Dependencies: 051_data_branching_cow.sql (routing layer)

-- Schema for merge tracking
CREATE TABLE pggit.merge_history (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    source_branch text NOT NULL,
    target_branch text NOT NULL,
    initiated_by text NOT NULL DEFAULT current_user,
    initiated_at timestamp NOT NULL DEFAULT now(),
    completed_at timestamp,
    status text NOT NULL CHECK (status IN ('in_progress', 'completed', 'failed', 'aborted')),
    conflict_count integer DEFAULT 0,
    resolved_conflicts integer DEFAULT 0,
    merge_strategy text DEFAULT 'auto',  -- 'auto', 'manual', 'ours', 'theirs'
    notes jsonb
);

CREATE INDEX idx_merge_history_branch ON pggit.merge_history(source_branch, target_branch);

-- Core merge function signature
CREATE OR REPLACE FUNCTION pggit.merge(
    p_source_branch text,
    p_target_branch text DEFAULT NULL,
    p_merge_strategy text DEFAULT 'auto'
)
RETURNS jsonb AS $$
DECLARE
    v_target_branch text;
    v_conflicts jsonb;
    v_merge_id uuid;
BEGIN
    -- Default target to current branch if not specified
    v_target_branch := coalesce(p_target_branch,
        coalesce(current_setting('pggit.current_branch', true), 'main'));

    -- Validate branches exist
    IF NOT EXISTS (SELECT 1 FROM pggit.branches WHERE name = p_source_branch) THEN
        RAISE EXCEPTION 'Source branch % does not exist', p_source_branch;
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pggit.branches WHERE name = v_target_branch) THEN
        RAISE EXCEPTION 'Target branch % does not exist', v_target_branch;
    END IF;

    -- Create merge record
    INSERT INTO pggit.merge_history(source_branch, target_branch, status)
    VALUES (p_source_branch, v_target_branch, 'in_progress')
    RETURNING id INTO v_merge_id;

    -- Detect conflicts
    v_conflicts := pggit.detect_conflicts(p_source_branch, v_target_branch);

    -- If no conflicts and auto strategy, perform merge
    IF (v_conflicts->>'conflict_count')::integer = 0 AND p_merge_strategy = 'auto' THEN
        PERFORM pggit._perform_merge(p_source_branch, v_target_branch, v_merge_id);

        UPDATE pggit.merge_history
        SET status = 'completed', completed_at = now()
        WHERE id = v_merge_id;

        RETURN jsonb_build_object(
            'merge_id', v_merge_id,
            'status', 'completed',
            'conflicts_found', 0,
            'conflicts_resolved', 0
        );
    ELSE
        -- Return conflict info for manual resolution
        RETURN jsonb_build_object(
            'merge_id', v_merge_id,
            'status', 'awaiting_conflict_resolution',
            'conflicts', v_conflicts
        );
    END IF;
END
$$ LANGUAGE plpgsql STRICT;

-- Function to actually perform the merge (internal)
CREATE OR REPLACE FUNCTION pggit._perform_merge(
    p_source_branch text,
    p_target_branch text,
    p_merge_id uuid
)
RETURNS void AS $$
DECLARE
    v_table record;
    v_source_schema text;
    v_target_schema text;
BEGIN
    -- Determine schema names
    v_source_schema := 'pggit_' || p_source_branch;
    v_target_schema := 'pggit_' || p_target_branch;

    -- For each table that changed in source branch
    FOR v_table IN
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = v_source_schema
    LOOP
        -- Copy changes from source to target
        -- This is simplified; real implementation handles conflicts, foreign keys, etc.
        EXECUTE format(
            'DELETE FROM %I.%I;
             INSERT INTO %I.%I SELECT * FROM %I.%I;',
            v_target_schema, v_table.table_name,
            v_target_schema, v_table.table_name,
            v_source_schema, v_table.table_name
        );
    END LOOP;

END
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION pggit.merge(text, text, text) IS
'Merge changes from source_branch into target_branch.
Returns merge status and any conflicts that require manual resolution.';
```

### Task 2.2: Create Conflict Detection

**New file:** `sql/053_conflict_detection.sql`

```sql
-- File: sql/053_conflict_detection.sql
-- Purpose: Detect merge conflicts between branches
-- Dependencies: 052_merge_operations.sql

-- Table for tracking conflicts
CREATE TABLE pggit.merge_conflicts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    merge_id uuid NOT NULL REFERENCES pggit.merge_history(id),
    table_name text NOT NULL,
    conflict_type text NOT NULL,  -- 'schema_change', 'data_change', 'dependency'
    source_change jsonb,
    target_change jsonb,
    source_value text,
    target_value text,
    resolution text,  -- NULL = unresolved, 'ours', 'theirs', 'custom'
    resolved_at timestamp,
    resolved_by text
);

-- Core conflict detection function
CREATE OR REPLACE FUNCTION pggit.detect_conflicts(
    p_source_branch text,
    p_target_branch text
)
RETURNS jsonb AS $$
DECLARE
    v_conflicts jsonb := '[]'::jsonb;
    v_conflict_count integer := 0;
    v_table record;
    v_source_schema text;
    v_target_schema text;
    v_table_conflict jsonb;
BEGIN
    v_source_schema := 'pggit_' || p_source_branch;
    v_target_schema := 'pggit_' || p_target_branch;

    -- Check for schema conflicts (tables added/removed)
    FOR v_table IN
        SELECT t1.table_name, 'added' as change_type
        FROM information_schema.tables t1
        LEFT JOIN information_schema.tables t2
            ON t1.table_name = t2.table_name AND t2.table_schema = v_target_schema
        WHERE t1.table_schema = v_source_schema AND t2.table_name IS NULL
        UNION ALL
        SELECT t1.table_name, 'removed' as change_type
        FROM information_schema.tables t1
        LEFT JOIN information_schema.tables t2
            ON t1.table_name = t2.table_name AND t2.table_schema = v_source_schema
        WHERE t1.table_schema = v_target_schema AND t2.table_name IS NULL
    LOOP
        v_table_conflict := jsonb_build_object(
            'type', 'schema_conflict',
            'table_name', v_table.table_name,
            'change_type', v_table.change_type
        );
        v_conflicts := v_conflicts || jsonb_build_array(v_table_conflict);
        v_conflict_count := v_conflict_count + 1;
    END LOOP;

    -- Check for data conflicts (same rows modified in both branches)
    -- [Simplified - real implementation would compare row-by-row]

    RETURN jsonb_build_object(
        'conflict_count', v_conflict_count,
        'conflicts', v_conflicts
    );
END
$$ LANGUAGE plpgsql STRICT;

-- Function to resolve a conflict manually
CREATE OR REPLACE FUNCTION pggit.resolve_conflict(
    p_merge_id uuid,
    p_table_name text,
    p_resolution text  -- 'ours' (keep target), 'theirs' (use source), 'custom' (manual)
)
RETURNS void AS $$
BEGIN
    UPDATE pggit.merge_conflicts
    SET resolution = p_resolution,
        resolved_at = now(),
        resolved_by = current_user
    WHERE merge_id = p_merge_id AND table_name = p_table_name;
END
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION pggit.detect_conflicts(text, text) IS
'Detect conflicts between two branches. Returns array of conflicts that require resolution.';
```

### Task 2.3: Write v0.2 Tests

**New file:** `tests/test-schema-merge.sql`

```sql
-- File: tests/test-schema-merge.sql
-- Purpose: Test merge operations

DO $$ BEGIN
    RAISE NOTICE '=== Testing Schema Merge Operations ===';

    -- Test 1: Simple merge with no conflicts
    RAISE NOTICE 'Test 1: Simple merge without conflicts';

    -- Create main branch
    PERFORM pggit.create_branch('main', NULL);

    -- Create test table in main
    SET pggit.current_branch = 'main';
    CREATE TABLE test_users (id uuid PRIMARY KEY, name text);
    INSERT INTO test_users VALUES (gen_random_uuid(), 'Alice');

    -- Create feature branch
    PERFORM pggit.create_branch('feature/users', 'main');
    SET pggit.current_branch = 'feature/users';
    INSERT INTO test_users VALUES (gen_random_uuid(), 'Bob');

    -- Merge feature branch to main
    PERFORM pggit.merge('feature/users', 'main', 'auto');

    -- Verify merged
    SET pggit.current_branch = 'main';
    IF (SELECT COUNT(*) FROM test_users) = 2 THEN
        RAISE NOTICE 'PASS: Merge successful, 2 users in main';
    ELSE
        RAISE EXCEPTION 'FAIL: Merge failed, expected 2 users in main';
    END IF;

    -- Test 2: Merge with schema conflict
    RAISE NOTICE 'Test 2: Merge with schema conflict (table added in feature)';

    PERFORM pggit.create_branch('feature/orders', 'main');
    SET pggit.current_branch = 'feature/orders';
    CREATE TABLE test_orders (id uuid PRIMARY KEY, user_id uuid);

    SET pggit.current_branch = 'main';

    -- Try to merge
    DECLARE
        v_result jsonb;
    BEGIN
        v_result := pggit.merge('feature/orders', 'main', 'auto');

        IF (v_result->>'status') = 'awaiting_conflict_resolution' THEN
            RAISE NOTICE 'PASS: Conflict detected as expected';
        ELSE
            RAISE EXCEPTION 'FAIL: Expected conflict not detected';
        END IF;
    END;

    RAISE NOTICE '=== Merge Tests Complete ===';
END $$;
```

**Verification:**
```bash
make test
# Expected: All tests pass, including new merge tests
```

---

## Phase 1c: v0.3 Schema Diffing (Weeks 9-12)

### Task 3.1: Implement Schema Diffing

**New file:** `sql/054_schema_diffing.sql`

```sql
-- File: sql/054_schema_diffing.sql
-- Purpose: Generate schema diffs between branches

CREATE OR REPLACE FUNCTION pggit.schema_diff(
    p_branch_a text,
    p_branch_b text
)
RETURNS TABLE (
    change_type text,
    object_type text,
    object_name text,
    branch_a_definition text,
    branch_b_definition text,
    sql_to_sync text
) AS $$
DECLARE
    v_schema_a text;
    v_schema_b text;
BEGIN
    v_schema_a := 'pggit_' || p_branch_a;
    v_schema_b := 'pggit_' || p_branch_b;

    -- Find tables only in branch_a (removed in branch_b)
    RETURN QUERY
    SELECT
        'removed'::text,
        'TABLE'::text,
        t.table_name,
        format('CREATE TABLE %I.%I (...)', v_schema_a, t.table_name),
        NULL::text,
        format('DROP TABLE IF EXISTS %I.%I;', v_schema_b, t.table_name)
    FROM information_schema.tables t
    LEFT JOIN information_schema.tables t2
        ON t.table_name = t2.table_name AND t2.table_schema = v_schema_b
    WHERE t.table_schema = v_schema_a AND t2.table_name IS NULL;

    -- Find tables only in branch_b (added in branch_b)
    RETURN QUERY
    SELECT
        'added'::text,
        'TABLE'::text,
        t.table_name,
        NULL::text,
        format('CREATE TABLE %I.%I (...)', v_schema_b, t.table_name),
        format('CREATE TABLE %I.%I AS SELECT * FROM %I.%I;',
               v_schema_b, t.table_name, v_schema_a, t.table_name)
    FROM information_schema.tables t
    LEFT JOIN information_schema.tables t2
        ON t.table_name = t2.table_name AND t2.table_schema = v_schema_a
    WHERE t.table_schema = v_schema_b AND t2.table_name IS NULL;

    -- Find columns added/removed in existing tables
    RETURN QUERY
    SELECT
        CASE WHEN c.column_name IS NULL THEN 'column_removed'
             WHEN c2.column_name IS NULL THEN 'column_added'
             ELSE 'column_modified' END,
        'COLUMN'::text,
        t.table_name || '.' || c.column_name,
        c.data_type,
        c2.data_type,
        CASE WHEN c.column_name IS NULL THEN
            format('ALTER TABLE %I.%I DROP COLUMN %I;', v_schema_b, t.table_name, c.column_name)
        ELSE
            format('ALTER TABLE %I.%I ADD COLUMN %I %s;', v_schema_b, t.table_name, c.column_name, c.data_type)
        END
    FROM information_schema.columns c
    FULL OUTER JOIN information_schema.columns c2
        ON c.table_name = c2.table_name
        AND c.column_name = c2.column_name
        AND c2.table_schema = v_schema_b
    JOIN information_schema.tables t ON c.table_name = t.table_name
    WHERE c.table_schema = v_schema_a
        OR (c2.table_schema = v_schema_b AND c.column_name IS NULL);

END
$$ LANGUAGE plpgsql STABLE;

-- Function to generate a complete SQL patch file
CREATE OR REPLACE FUNCTION pggit.generate_patch(
    p_source_branch text,
    p_target_branch text
)
RETURNS text AS $$
DECLARE
    v_patch text := '';
    v_diff record;
BEGIN
    v_patch := '-- pgGit Schema Patch' || E'\n';
    v_patch := v_patch || '-- From: ' || p_source_branch || ' To: ' || p_target_branch || E'\n';
    v_patch := v_patch || '-- Generated: ' || now()::text || E'\n\n';

    FOR v_diff IN
        SELECT sql_to_sync FROM pggit.schema_diff(p_source_branch, p_target_branch)
        WHERE sql_to_sync IS NOT NULL
    LOOP
        v_patch := v_patch || v_diff.sql_to_sync || E'\n';
    END LOOP;

    RETURN v_patch;
END
$$ LANGUAGE plpgsql STABLE;

COMMENT ON FUNCTION pggit.schema_diff(text, text) IS
'Compare schemas between two branches and return differences.';
```

---

## Phase 1d: v1.0 Production Ready (Weeks 13-14)

### Task 4.1: Team Collaboration Features

**New functions in existing file or new:** `sql/055_team_features.sql`

```sql
-- Add team tracking to pggit.branch_history
ALTER TABLE pggit.branch_history ADD COLUMN IF NOT EXISTS modified_by text;

-- Function to get branch activity
CREATE OR REPLACE FUNCTION pggit.get_branch_activity(
    p_branch_name text,
    p_days_back integer DEFAULT 7
)
RETURNS TABLE (
    timestamp timestamp,
    operation text,
    user_name text,
    details jsonb
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        bh.timestamp,
        bh.operation,
        bh.modified_by,
        bh.details
    FROM pggit.branch_history bh
    JOIN pggit.branches b ON bh.branch_id = b.id
    WHERE b.name = p_branch_name
        AND bh.timestamp > now() - (p_days_back || ' days')::interval
    ORDER BY bh.timestamp DESC;
END
$$ LANGUAGE plpgsql STABLE;

-- Function to see who changed what table
CREATE OR REPLACE FUNCTION pggit.get_table_history(
    p_table_name text
)
RETURNS TABLE (
    changed_at timestamp,
    changed_by text,
    branch text,
    change_description text
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        ah.audit_timestamp,
        ah.audit_user,
        ah.branch_name,
        ah.description
    FROM pggit.audit_log ah
    WHERE ah.table_name = p_table_name
    ORDER BY ah.audit_timestamp DESC
    LIMIT 100;
END
$$ LANGUAGE plpgsql STABLE;
```

### Task 4.2: CI/CD Integration Examples

**Create:** `.github/workflows/pgGit-ci-cd.yml`

```yaml
name: pgGit CI/CD

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  schema-validation:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:17
        env:
          POSTGRES_PASSWORD: test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432

    steps:
    - uses: actions/checkout@v4

    - name: Install pgGit
      run: |
        PGPASSWORD=test psql -h localhost -U postgres -d postgres \
          -c "CREATE EXTENSION pggit CASCADE;"

    - name: Validate Schema
      run: |
        PGPASSWORD=test psql -h localhost -U postgres -d postgres \
          -c "SELECT pggit.validate_schema();"

    - name: Run Tests
      run: |
        PGPASSWORD=test psql -h localhost -U postgres -d postgres \
          -f tests/test-data-branching.sql

    - name: Generate Diff
      if: github.event_name == 'pull_request'
      run: |
        PGPASSWORD=test psql -h localhost -U postgres -d postgres \
          -c "SELECT pggit.generate_patch('main', 'HEAD');" > schema-diff.sql

    - name: Comment PR with Diff
      if: github.event_name == 'pull_request'
      uses: actions/github-script@v7
      with:
        script: |
          const fs = require('fs');
          const diff = fs.readFileSync('schema-diff.sql', 'utf8');
          github.rest.issues.createComment({
            issue_number: context.issue.number,
            owner: context.repo.owner,
            repo: context.repo.repo,
            body: '## Schema Changes\n```sql\n' + diff + '\n```'
          });
```

### Task 4.3: Performance Optimizations

```sql
-- Add indexes for common queries
CREATE INDEX idx_branches_parent ON pggit.branches(parent_id);
CREATE INDEX idx_branches_status ON pggit.branches(status);
CREATE INDEX idx_branch_history_timestamp ON pggit.branch_history(timestamp DESC);
CREATE INDEX idx_merge_history_status ON pggit.merge_history(status);

-- Optimize routing function (already done in view-based routing)
-- Make sure query planner can understand intent
```

---

## Summary: Phase 1 Deliverables

### Code Files Created/Modified

**New SQL Files:**
- `sql/052_merge_operations.sql` - Merge logic
- `sql/053_conflict_detection.sql` - Conflict detection
- `sql/054_schema_diffing.sql` - Schema diffing
- `sql/055_team_features.sql` - Team collaboration

**New Test Files:**
- `tests/test-schema-merge.sql` - Merge tests
- `tests/test-schema-diff.sql` - Diff tests

**New Documentation:**
- `docs/ARCHITECTURE.md` - Design documentation
- `GOVERNANCE.md` - Governance model
- `ROADMAP.md` - 18-month roadmap

**New CI/CD:**
- `.github/workflows/pgGit-ci-cd.yml` - Automated testing

**Modified Files:**
- `README.md` - Moon shot vision
- `tests/test-data-branching.sql` - Remove Tests 2, 5, 6
- `Makefile` - Ensure tests run

### Deliverable Quality Metrics

**v0.1.4:**
- ✅ All 12 tests pass
- ✅ Installation works on PG 15-18
- ✅ Zero critical security issues
- ✅ Documentation complete
- ✅ Roadmap published

**v0.2:**
- ✅ Merge operations functional
- ✅ Conflict detection working
- ✅ 20+ production users
- ✅ Merge tests passing

**v0.3:**
- ✅ Schema diffing complete
- ✅ Patch generation working
- ✅ 50+ production users

**v1.0:**
- ✅ Production-ready
- ✅ 100+ production users
- ✅ 1500+ GitHub stars
- ✅ Acquisition interest

---

# PHASE 2: TEMPORAL QUERIES (Months 4-6)

## Architecture Decision: Context-Based Routing

The key to making Phase 2+ work without breaking Phase 1:

**Current (Phase 1):**
```
View routing context: { branch: 'X' }
Route logic: SELECT * FROM pggit_X.table_name
```

**Extended (Phase 2+):**
```
View routing context: { branch: 'X', timestamp: 'T' }
Route logic: SELECT * FROM pggit_X_v{version_number}.table_name
  where version_number = find_version_at_time(T)
```

### Task: Extend Routing Infrastructure

**Modify:** `sql/051_data_branching_cow.sql`

```sql
-- Extend context system to support timestamps
CREATE OR REPLACE FUNCTION pggit._get_routing_context()
RETURNS jsonb AS $$
DECLARE
    v_context jsonb;
BEGIN
    v_context := jsonb_build_object(
        'branch', coalesce(current_setting('pggit.current_branch', true), 'main'),
        'timestamp', coalesce(current_setting('pggit.query_timestamp', true), NULL),
        'version', coalesce(current_setting('pggit.query_version', true), NULL)
    );
    RETURN v_context;
END
$$ LANGUAGE plpgsql STABLE;

-- Updated routing function signature (backward compatible)
CREATE OR REPLACE FUNCTION pggit._route_table(
    p_schema_name text,
    p_table_name text,
    p_context jsonb DEFAULT NULL
)
RETURNS text AS $$
DECLARE
    v_context jsonb;
    v_branch text;
    v_timestamp timestamp;
    v_version text;
BEGIN
    v_context := coalesce(p_context, pggit._get_routing_context());

    v_branch := v_context->>'branch';
    v_timestamp := (v_context->>'timestamp')::timestamp;
    v_version := v_context->>'version';

    -- Phase 1: Just branch routing
    IF v_timestamp IS NULL THEN
        RETURN format('pggit_%s', v_branch);
    END IF;

    -- Phase 2+: Branch + temporal routing
    -- Find appropriate version for timestamp
    v_version := pggit._find_version_at_time(v_branch, v_timestamp);
    RETURN format('pggit_%s_v%s', v_branch, v_version);
END
$$ LANGUAGE plpgsql STABLE;
```

---

## Phase 2 Implementation Tasks (NOT in Phase 1)

### Task 1: Create Temporal Version Table

```sql
-- Phase 2: Will create pggit.versions table
CREATE TABLE pggit.versions (
    id uuid PRIMARY KEY,
    branch_id uuid REFERENCES pggit.branches(id),
    version_number integer,
    snapshot_timestamp timestamp NOT NULL,
    created_at timestamp DEFAULT now(),
    description text,

    UNIQUE(branch_id, version_number)
);
```

### Task 2: Create Snapshot Functions

```sql
-- Phase 2: Will implement snapshot capture
CREATE OR REPLACE FUNCTION pggit._create_snapshot(
    p_branch text,
    p_description text DEFAULT NULL
)
RETURNS uuid AS $$
-- Captures current state of all tables at a point in time
-- Creates pggit_branch_vN schemas with snapshots
$$ LANGUAGE plpgsql;
```

---

# PHASE 3: COMPLIANCE & AUDIT (Months 7-9)

## Architecture: Independent Audit Layer

**Key Design:** Audit is orthogonal to routing

- Phase 1: Routing works (which version to read)
- Phase 3: Audit captures (what changed, who did it)

### Task 1: Create Immutable Audit Schema

```sql
-- Phase 3: Create immutable audit storage
CREATE SCHEMA pggit_audit_compliance;

CREATE TABLE pggit_audit_compliance.audit_log (
    id uuid PRIMARY KEY,
    table_name text NOT NULL,
    operation text NOT NULL,  -- INSERT, UPDATE, DELETE
    old_values jsonb,
    new_values jsonb,
    audit_timestamp timestamp NOT NULL,
    audit_user text NOT NULL,
    audit_query_id uuid
);

-- Make immutable (append-only)
ALTER TABLE pggit_audit_compliance.audit_log DISABLE TRIGGER ALL;
CREATE TRIGGER audit_log_immutable
BEFORE UPDATE OR DELETE ON pggit_audit_compliance.audit_log
FOR EACH ROW EXECUTE FUNCTION pggit._prevent_audit_modification();
```

---

# PHASE 4: OPTIMIZATION (Months 10-12)

## Architecture: Transparent CoW Layer

**Key Design:** Optimization doesn't change query results, just storage

### Task 1: Create CoW Deduplication

```sql
-- Phase 4: Copy-on-write implementation
CREATE SCHEMA pggit_optimize;

CREATE TABLE pggit_optimize.block_references (
    block_id uuid PRIMARY KEY,
    branch_id uuid REFERENCES pggit.branches(id),
    source_block_id uuid,  -- Reference to parent block
    block_data bytea,
    compression_ratio decimal,

    UNIQUE(branch_id, block_id)
);

-- When a branch is created, reference parent blocks instead of copying
-- Only copy blocks when they're modified (copy-on-write)
```

---

# PHASE 5: BUSINESS LAYER (Months 13-15)

## Tasks (NOT implemented in Phase 1)

- pgGit Cloud web application
- Team dashboard
- GitHub/GitLab integrations
- IDE plugins

---

# PHASE 6: EXPANSION (Months 16-18)

## Tasks (NOT implemented in Phase 1)

- pgTime (temporal database product)
- pgAudit (compliance product)
- pgPerf (performance product)

---

## Conclusion

This technical decomposition shows:

1. **Phase 1 is concrete and executable**
   - Specific files to create/modify
   - Specific functions to implement
   - Specific tests to write
   - ~4-6 weeks of focused work

2. **Phases 2-6 are architecturally ready**
   - Context system designed to extend
   - Audit layer designed independently
   - Optimization layer designed transparently
   - Each phase adds without breaking

3. **Zero breaking changes**
   - Phase 1 API remains unchanged when Phase 2+ added
   - Queries written for Phase 1 still work in Phase 6

4. **Market validation gates**
   - After v1.0: Decide if Phase 2 is worth it
   - Based on actual user demand, not speculation

This is how you build a platform: one solid phase, then extend based on real market feedback.
