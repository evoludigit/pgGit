# pgGit Development Phases

## Current Status: v0.1.3 - Stabilization Phase

**Last Updated:** 2026-02-04
**Overall Progress:** 70% - Basic functionality stable, advanced features incomplete

---

## Phase Overview

This document outlines all phases from current state through finalization.

### Completed Phases
✅ Phase 0: Initial foundation
✅ Phase 1: Core git operations
✅ Phase 2: DDL capture & audit trail
✅ Phase 3: Data branching (basic, via view-based routing)

### Current/Upcoming Phases
🟡 Phase 4: Stabilization & validation (IN PROGRESS)
⏳ Phase 5: Advanced features (BLOCKED - awaiting decision)
⏳ Phase 6: Security hardening (PENDING community input)
⏳ Phase 7: Finalization

---

## The Foundational Problem Solved

### Issue Chain: From Installation → Data Branching → Advanced Features

**Problem Discovered (Issue #12):**
```
Data branching tests failed because PostgreSQL's PL/pgSQL plan caching
resolves table OIDs at COMPILE time, not execution time.

When search_path was changed at runtime, cached plans ignored the change
and still referenced the original table OID.

Result: Branch switching didn't work - all queries hit the main branch tables.
```

**Root Technical Issue:**
```
Original Approach (BROKEN):
┌───────────────────────────────────┐
│ SET search_path = 'pggit_branch1' │
│ SELECT * FROM products;           │
│ ↓ PostgreSQL caches table OID    │
│   at COMPILE time                 │
│ ↓                                 │
│ SET search_path = 'main'          │
│ SELECT * FROM products;           │
│ ↑ Still uses cached OID!          │
│ → Still reads main branch tables  │
└───────────────────────────────────┘
```

**Solution Implemented (PR #15):**
```
View-Based Routing (WORKS):
┌─────────────────────────────────────────────────┐
│ public.products ← Now a VIEW, not a table      │
│         ↓                                       │
│ route_products_select()                         │
│         ↓                                       │
│ EXECUTE 'SELECT * FROM pggit_base.products'    │
│ or                                              │
│ EXECUTE 'SELECT * FROM pggit_branch1.products' │
│ ↑ Dynamic SQL = evaluated at RUNTIME           │
│ ↑ Forces resolution every time, defeats cache  │
└─────────────────────────────────────────────────┘
```

### Why This Matters
This fix revealed that the test suite was incomplete. It showed us we need to decide:
- Should we implement temporal branching properly?
- Should we implement copy-on-write efficiently?
- Or mark these as future work and skip the tests?

---

## What's Currently Pending

### 1. Immediate Merges (Ready Now)

**PR #6: Make Install Validation**
- Status: READY TO MERGE
- What: Validates that `make install` works correctly
- Includes: Docker test suite with 31 tables, 66+ functions verification
- Blocks: None (can merge independently)

**PR #7, #8, #9: GitHub Actions Updates**
- Status: READY TO MERGE
- What: Update CI/CD actions to latest versions (Node.js 24 support)
- Blocks: None (can merge independently)

### 2. Feature Decision (Issue #16)

**Decision Needed: What about the incomplete tests?**

**Option A: Implement Features**
- Implement `create_temporal_branch()` properly
- Implement `optimize_branch_storage()`
- Verify copy-on-write efficiency calculations
- Timeline: Medium-High effort
- Benefit: Complete feature set for v0.1.4/v0.2.0

**Option B: Mark as Aspirational**
- Skip tests with TODO comments
- Document what would be needed
- Focus resources elsewhere
- Timeline: Minimal effort
- Benefit: Cleaner test suite, clear roadmap

**Recommended:** Option B (mark aspirational) - allows release v0.1.4 while collecting requirements for v0.2.0

### 3. Security Audit (Issue #3)

**Status:** OPEN, seeking community participation
**Scope:**
- SQL injection vulnerabilities
- Privilege escalation risks
- Input validation & sanitization
- Access control mechanisms

**Current Posture:**
```
✓ No built-in auth (uses PostgreSQL)
✓ No SECURITY DEFINER functions
✓ Audit trail logging enabled
⚠ Experimental codebase - needs expert review
```

**What Needs to Happen:**
- Community reviews security checklist in `docs/security/SECURITY_AUDIT.md`
- Run semgrep scans against critical files
- Test vulnerability cases
- Report findings (target: 48hr response for critical items)

---

## Complete Work Breakdown

### Phase 4: Stabilization & Validation (CURRENT)

**Objective:** Merge pending fixes, complete test suite, validate all platforms

**Work Items:**

#### Cycle 1: Merge Pending Changes
- Merge PR #6 (make install validation)
- Merge PR #7, #8, #9 (GitHub Actions)
- Verify all tests pass after merges
- Commit: "chore: Merge pending PRs and dependency updates"

#### Cycle 2: Decide on Advanced Features (Issue #16)
- [ ] Review test 2-6 in `test-data-branching.sql`
- [ ] Evaluate implementation effort for temporal/COW features
- [ ] Make decision: implement or mark aspirational
- [ ] If mark aspirational: add SKIP and TODO comments
- [ ] If implement: break out into Phase 5 cycles
- Commit: "docs: Document decision on advanced branching features"

#### Cycle 3: Validate on All Platforms
- [ ] Test on PostgreSQL 15, 16, 17, 18
- [ ] Verify `make install`, `make test`, `make clean`
- [ ] Verify Docker installation path
- [ ] Document any platform-specific notes
- Commit: "test: Complete multi-version compatibility validation"

#### Cycle 4: Promote Security Audit
- [ ] Post issue update to Reddit r/PostgreSQL
- [ ] Cross-post to PostgreSQL security lists
- [ ] Mention in release notes
- [ ] Set up issue milestones (2-week review window)
- Commit: "docs: Promote security audit request (v0.1.3)"

---

### Phase 5: Advanced Features (BLOCKED - Awaiting Phase 4 Decision)

**Objective:** Implement temporal branching and storage optimization

**Only proceed if Phase 4, Cycle 2 decides to implement features**

#### Cycle 1: Temporal Branching Implementation
- [ ] Implement proper `create_temporal_branch()` function
- [ ] Copy table schemas and data to temporal branch
- [ ] Handle timestamps and versioning
- [ ] Test with multi-table branching scenario
- Commit: "feat(branching): Implement temporal branching"

#### Cycle 2: Copy-on-Write Efficiency
- [ ] Implement `optimize_branch_storage()` properly
- [ ] Populate `branch_storage_stats` correctly
- [ ] Calculate COW savings accurately
- [ ] Test COW ratio calculations
- Commit: "feat(branching): Implement storage optimization"

#### Cycle 3: Advanced Feature Tests
- [ ] Enable and pass tests 2-6 in test-data-branching.sql
- [ ] Document performance characteristics
- [ ] Add examples to documentation
- Commit: "test(branching): Complete advanced feature validation"

---

### Phase 6: Security Hardening

**Objective:** Address security audit findings and add defensive measures

**Only proceed after Phase 4, Cycle 4 receives community feedback**

#### Cycle 1: Critical Findings
- [ ] Fix critical findings (if any reported)
- [ ] Document mitigations
- [ ] Add tests for vulnerability scenarios
- Commit: "security: Fix critical audit findings"

#### Cycle 2: Recommendations
- [ ] Implement recommended improvements
- [ ] Add input validation where needed
- [ ] Harden SQL parsing against injection
- Commit: "security: Implement audit recommendations"

#### Cycle 3: Documentation
- [ ] Update security documentation
- [ ] Add security best practices guide
- [ ] Document audit timeline and results
- Commit: "docs(security): Document audit results and recommendations"

---

### Phase 7: Finalization

**Objective:** Polish repository, remove development artifacts, prepare for release

#### Cleanup Tasks
- [ ] Remove all `.phases/` directory
- [ ] Remove any // Phase comments from code
- [ ] Remove any TODO/FIXME without corresponding issue
- [ ] Update README with final status
- [ ] Verify no development markers remain
- [ ] Run final linting pass
- [ ] Update CHANGELOG.md
- [ ] Tag release v0.1.4 (or v0.2.0 if Phase 5 implemented)

---

## Contributor Context

### stephengibson12
- Merged 5 PRs fixing critical issues
- Discovered and explained the PL/pgSQL plan caching problem
- Extended data branching with view-based routing
- Quote: "I was fascinated by your project and ended up getting absorbed into it. One fix led to uncovering other issues. I used Claude Code extensively."

### evoludigit (Project Owner)
- Maintaining PR #6 validation
- Managing security audit request
- Version releases and roadmap

---

## Success Criteria

### v0.1.4 Release (Target: ~2 weeks)
- [x] 12/13 tests passing
- [x] make install validated
- [x] PostgreSQL 15-18 tested
- [ ] Advanced features decision made (Phase 4 Cycle 2)
- [ ] Security audit promoted (Phase 4 Cycle 4)
- [ ] All PRs merged
- [ ] Repository cleaned (Phase 7)

### v0.2.0 Release (Future, conditional)
- Only if Phase 5 (advanced features) is implemented
- Temporal branching fully functional
- Copy-on-write optimizations complete
- Security audit findings addressed

---

## Dependencies Between Phases

```
Phase 4 (Stabilization) ← CURRENT, must complete before anything else
    ↓
Phase 5 (Advanced) ← Blocked on Phase 4 Cycle 2 decision
    ↓
Phase 6 (Security) ← Blocked on community audit feedback
    ↓
Phase 7 (Finalization) ← Blocks v0.1.4/v0.2.0 release
```

---

## Recent Commits Reference

Latest commits show the progression:
```
ebe0d0a chore: Bump version to 0.1.3
40ccf92 docs: Align pgGit docs with Confiture's actual implementation
b38f390 docs: Reposition pgGit as development tool with compliance production support
a99f4c7 docs: Complete documentation updates for Phase 1-3 backup quality improvements
ce114b5 feat(backup): Add reliability features with idempotency, structured errors, and audit logging
```

Next commits will be:
```
NEXT: Merge pending PRs (Phase 4 Cycle 1)
NEXT: Make decision on advanced features (Phase 4 Cycle 2)
THEN: Address audit findings (Phase 6)
FINAL: Clean repository (Phase 7)
```

---

## Key Files to Know

**Core Implementation:**
- `sql/051_data_branching_cow.sql` - View-based routing (the main fix)
- `sql/075_audit_log.sql` - Parameter ordering fix
- `sql/002_event_triggers.sql` - DDL capture

**Testing:**
- `tests/test-data-branching.sql` - Comprehensive branching tests (1 passes, 2-6 aspirational)
- `tests/test-make-install.sh` - Installation validation
- `tests/test-*.sql` - Other test suites

**Documentation:**
- `docs/security/SECURITY_AUDIT.md` - Security checklist
- `CONTRIBUTING.md` - Development guide
- `README.md` - User-facing documentation

---

## How to Use This Document

1. **As Project Owner:** Use this to track progress and make phase decisions
2. **As Contributor:** Understand what's planned, choose a phase to contribute to
3. **As Reviewer:** See what's blocked and what's ready for merging
4. **As User:** Understand timeline to feature completeness

Start with Phase 4 - it's ready to go now.
