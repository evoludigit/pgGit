# v0.2: Merge Operations - Detailed Technical Plan

**Target Release Date**: April 15, 2026
**Duration**: 6 weeks (March 1 - April 15)
**Lead**: stephengibson12 (Technical Architect)
**Status**: 🚀 READY TO BEGIN (Phase 1 foundation complete)

---

## Executive Summary

v0.2 adds the core merge functionality to pgGit. Developers can now merge schema branches with automatic conflict detection and manual resolution capabilities. This is the bridge between individual development (v0.1.4 branching) and team collaboration.

**What Ships in v0.2:**
- `pggit.merge(source, target, strategy)` - Merge two branches
- `pggit.detect_conflicts(source, target)` - Identify conflicts
- `pggit.resolve_conflict(merge_id, table, resolution)` - Manual resolution
- Merge history tracking and audit trail

**Developer Experience:**
```sql
-- Merge feature into main
SELECT pggit.merge('feature/new-api', 'main');
-- Returns: {"merge_id": "...", "status": "completed"|"awaiting_resolution", ...}

-- If conflicts exist:
SELECT * FROM pggit.get_conflicts(merge_id);
-- Resolve each conflict:
SELECT pggit.resolve_conflict(merge_id, 'users', 'ours');
-- Complete merge:
SELECT pggit._complete_merge_after_resolution(merge_id);
```

---

## Database Schema Changes

### New Table: pggit.merge_history

```sql
CREATE TABLE pggit.merge_history (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    source_branch text NOT NULL,
    target_branch text NOT NULL,
    initiated_by text NOT NULL DEFAULT current_user,
    initiated_at timestamp NOT NULL DEFAULT now(),
    completed_at timestamp,
    status text NOT NULL DEFAULT 'in_progress' CHECK (status IN (
        'in_progress',
        'completed',
        'failed',
        'aborted',
        'awaiting_resolution'
    )),
    conflict_count integer DEFAULT 0,
    resolved_conflicts integer DEFAULT 0,
    unresolved_conflicts integer DEFAULT 0,
    merge_strategy text DEFAULT 'auto',
    error_message text,
    notes jsonb DEFAULT '{}'::jsonb
);

CREATE INDEX idx_merge_history_status ON pggit.merge_history(status);
CREATE INDEX idx_merge_history_branches ON pggit.merge_history(source_branch, target_branch);
CREATE INDEX idx_merge_history_time ON pggit.merge_history(initiated_at DESC);
```

### New Table: pggit.merge_conflicts

```sql
CREATE TABLE pggit.merge_conflicts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    merge_id uuid NOT NULL REFERENCES pggit.merge_history(id) ON DELETE CASCADE,
    table_name text NOT NULL,
    conflict_type text NOT NULL,
    -- Types: table_added, table_removed, table_modified
    --        column_added, column_removed, column_modified
    --        constraint_added, constraint_removed, constraint_modified
    source_definition text,
    target_definition text,
    resolution text DEFAULT NULL,
    -- NULL = unresolved, 'ours' = keep target, 'theirs' = use source, 'custom'
    resolved_at timestamp,
    resolved_by text,
    resolution_notes text,

    UNIQUE(merge_id, table_name, conflict_type),
    FOREIGN KEY (merge_id) REFERENCES pggit.merge_history(id)
);

CREATE INDEX idx_merge_conflicts_merge ON pggit.merge_conflicts(merge_id);
CREATE INDEX idx_merge_conflicts_unresolved ON pggit.merge_conflicts(merge_id, resolution)
    WHERE resolution IS NULL;
```

---

## Functions to Implement

### 1. pggit.merge()

**Signature:**
```sql
CREATE OR REPLACE FUNCTION pggit.merge(
    p_source_branch text,
    p_target_branch text DEFAULT NULL,
    p_merge_strategy text DEFAULT 'auto'
)
RETURNS jsonb AS $$
-- Returns: {
--   "merge_id": "uuid",
--   "status": "completed" | "awaiting_resolution",
--   "conflicts": [{"table": "...", "type": "...", "action": "..."}],
--   "tables_merged": 42,
--   "conflict_count": 3
-- }
$$
LANGUAGE plpgsql;
```

**Behavior:**
1. Validate both branches exist
2. If `p_target_branch` is NULL, use current branch
3. Get list of all tables in both branch schemas
4. Call `detect_conflicts()` to identify schema conflicts
5. If strategy='auto' and no conflicts:
   - Perform automatic merge (copy table definitions)
   - Update `merge_history` status to 'completed'
   - Return success response
6. If conflicts exist or strategy='manual':
   - Create `merge_history` record with status 'awaiting_resolution'
   - Create `merge_conflicts` records for each conflict
   - Return conflict details
   - Wait for manual resolution via `resolve_conflict()`

**Implementation Notes:**
- Transaction safety: Use savepoints for rollback on error
- Idempotency: Merging the same branches twice should be safe
- Performance: Cache schema information where possible
- Error handling: Return detailed error messages

### 2. pggit.detect_conflicts()

**Signature:**
```sql
CREATE OR REPLACE FUNCTION pggit.detect_conflicts(
    p_source_branch text,
    p_target_branch text
)
RETURNS jsonb AS $$
-- Returns: {
--   "conflict_count": 3,
--   "conflicts": [
--     {"table": "users", "type": "table_added", "in_branch": "source"},
--     {"table": "products", "type": "column_added", "column": "sku", "in_branch": "source"},
--     ...
--   ]
-- }
$$
LANGUAGE plpgsql;
```

**Conflict Detection Logic:**

For each table in source_branch:
```
IF table NOT IN target_branch:
  → Conflict: table_added
ELSE IF table IN target_branch:
  FOR each column in source_branch table:
    IF column NOT IN target_branch table:
      → Conflict: column_added
    ELSE:
      Compare: type, constraints, default, nullable
      IF different:
        → Conflict: column_modified
  FOR each column in target_branch table NOT in source:
    → Conflict: column_removed (in source, present in target)

  Compare other schema objects:
  - Indexes, constraints, triggers
  - For each difference:
    → Conflict: object_modified or object_removed or object_added
```

**Implementation Notes:**
- Query `information_schema.columns`, `information_schema.tables`, etc.
- Build comparison of DDL between branch schemas
- Return structured conflict data
- Distinguish additive vs breaking changes

### 3. pggit.resolve_conflict()

**Signature:**
```sql
CREATE OR REPLACE FUNCTION pggit.resolve_conflict(
    p_merge_id uuid,
    p_table_name text,
    p_resolution text, -- 'ours' | 'theirs' | 'custom'
    p_custom_definition text DEFAULT NULL
)
RETURNS void AS $$
$$
LANGUAGE plpgsql;
```

**Behavior:**
1. Validate merge exists and is in 'awaiting_resolution' status
2. Find matching conflict record
3. Update resolution based on choice:
   - `ours`: Keep target_branch version
   - `theirs`: Use source_branch version
   - `custom`: Use provided definition
4. Update `merge_conflicts` record with resolution
5. Check if all conflicts resolved
6. If all resolved:
   - Call internal `_complete_merge_after_resolution()`
   - Update `merge_history` status to 'completed'

### 4. pggit._complete_merge_after_resolution()

**Internal function (prefixed with _):**
```sql
CREATE OR REPLACE FUNCTION pggit._complete_merge_after_resolution(
    p_merge_id uuid
)
RETURNS void AS $$
$$
LANGUAGE plpgsql;
```

**Behavior:**
1. Get merge_id record
2. Get all resolved conflicts
3. For each resolved conflict:
   - Apply the resolution to target_branch schema
4. Verify all changes applied successfully
5. Create merge commit in `pggit.commits` table
6. Update `merge_history.status` to 'completed'
7. Update `merge_history.completed_at` timestamp

---

## Test Cases

### Test Suite: tests/test-schema-merge.sql

**Test 1: Simple Merge Without Conflicts**
```
1. Create branch A from main with table 'users'
2. Create branch B from main
3. In branch A: Add column 'email'
4. Merge A into B
   Expected: Merge succeeds immediately
   Expected: B now has 'users' table with 'email' column
   Expected: merge_history shows 'completed' status
```

**Test 2: Table Added in Source**
```
1. Create main with table 'users'
2. Create branch 'feature' from main
3. In feature: Add table 'orders'
4. Merge feature into main
   Expected: Conflict detected (table_added)
   Expected: merge_history shows 'awaiting_resolution'
   Expected: merge_conflicts has record for 'orders'
5. Resolve with 'theirs'
   Expected: 'orders' table now in main
   Expected: merge_history shows 'completed'
```

**Test 3: Column Modified in Both Branches**
```
1. Create main with 'users(id, name, email TEXT)'
2. Create branch A, modify email column type to VARCHAR(100)
3. Create branch B, add constraint to email
4. Merge A into main
   Expected: Conflict (column_modified)
   Expected: Awaiting resolution
5. Resolve with 'theirs' (keep A's change)
   Expected: merge_history shows 'completed'
```

**Test 4: Incompatible Changes**
```
1. Create main with 'users(id, name)'
2. Create branch A, rename 'name' to 'full_name'
3. Create branch B, add column 'first_name'
4. Merge A into main
   Expected: Conflict detected
5. Resolve with 'ours'
   Expected: Merge completes with custom resolution
```

**Test 5: Concurrent Merge Attempts**
```
1. Start merge M1 in one connection
2. Start merge M2 in another connection on same branches
   Expected: Both succeed (no blocking)
   Expected: Both have separate merge_history records
   Expected: Second merge sees state after first
```

**Test 6: Merge Idempotency**
```
1. Merge A into B successfully
2. Merge A into B again
   Expected: Second merge also succeeds
   Expected: Detects already-merged changes
   Expected: No duplicate conflicts
```

**Test 7: Merge with Foreign Keys**
```
1. Create 'customers' and 'orders' with FK
2. In branch: Add constraint to FK
3. Merge back
   Expected: FK constraint preserved
   Expected: No referential integrity errors
```

**Test 8: Large Schema Merge**
```
1. Create schema with 50+ tables
2. Merge with 20+ changes across tables
   Expected: Merge completes successfully
   Expected: Performance acceptable (< 5 seconds)
   Expected: All changes applied correctly
```

---

## Implementation Roadmap

### Week 1 (Mar 1-7): Design & Setup
- [ ] Review database schema with team
- [ ] Create migration file (sql/052_merge_operations.sql)
- [ ] Create merge history and conflicts tables
- [ ] Create foundation functions with stubs
- [ ] Set up test environment

### Week 2 (Mar 8-14): Conflict Detection
- [ ] Implement `detect_conflicts()` function
- [ ] Build schema comparison logic
- [ ] Add conflict classification
- [ ] Test against various scenarios

### Week 3 (Mar 15-21): Merge Logic
- [ ] Implement `merge()` function
- [ ] Add automatic merge handling
- [ ] Add conflict tracking
- [ ] Add merge history recording

### Week 4 (Mar 22-28): Resolution & Completion
- [ ] Implement `resolve_conflict()` function
- [ ] Implement `_complete_merge_after_resolution()`
- [ ] Add resolution application logic
- [ ] Add merge commit creation

### Week 5 (Mar 29-Apr 4): Testing
- [ ] Write comprehensive test suite
- [ ] Test edge cases and error scenarios
- [ ] Performance testing (large schemas)
- [ ] Concurrency testing

### Week 6 (Apr 5-11): Polish & Release Prep
- [ ] Documentation for merge workflow
- [ ] CLI examples and guides
- [ ] Release notes preparation
- [ ] Final QA and bug fixes

### Release (Apr 15): v0.2 Launch
- [ ] Create release commit
- [ ] Tag v0.2
- [ ] Publish GitHub release
- [ ] Community announcement

---

## Success Criteria

✅ **Functional:**
- Merge works without conflicts (auto-merge)
- Conflicts detected correctly
- Manual resolution works
- Merge history recorded accurately
- Idempotent behavior maintained

✅ **Quality:**
- All tests passing (100% pass rate)
- No data loss
- Proper error handling
- Clear error messages
- Transaction safety

✅ **Performance:**
- Merge of 100-table schema completes in < 5 seconds
- Query planning/execution efficient
- Minimal memory usage

✅ **Documentation:**
- Merge workflow guide complete
- API reference updated
- Examples provided
- Error handling documented

✅ **Community:**
- Release notes published
- Documentation updated
- Examples working
- Community engaged

---

## Risk Mitigation

### Technical Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|-----------|
| Circular dependencies in merge | Medium | High | Detect and handle in logic, test extensively |
| Foreign key constraint violations | Medium | High | Validate constraints before applying changes |
| Performance degradation with large schemas | Medium | Medium | Profile early, optimize queries |
| Race conditions in concurrent merges | Low | High | Use database-level locking, test concurrency |

### Schedule Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|-----------|
| Stephen unavailable | Low | High | Have backup implementation plan |
| Scope creep (Phase 2+ features requested) | High | Medium | Strict governance ("Is this merge ops?") |
| Testing takes longer than expected | Medium | Medium | Add test resources early |

### Community Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|-----------|
| Users want Phase 2 features | High | Low | Refer to GOVERNANCE.md, explain roadmap |
| Conflicts harder than expected | Medium | Medium | Publish design early for feedback |
| Edge cases discovered in beta | Medium | Low | Gather feedback, fix in patches |

---

## Dependencies & Blockers

### Requires (Must Complete First):
- ✅ Phase 1 foundation (v0.1.4) - COMPLETE
- ✅ GOVERNANCE.md established - COMPLETE
- ✅ Architecture documented - COMPLETE

### Blocks:
- v0.3 (Schema Diffing) - depends on merge operations working
- v1.0 (Production Ready) - depends on v0.2 + v0.3

### External Dependencies:
- stephengibson12 availability for implementation
- PostgreSQL 15-17 test environment
- Community feedback on design

---

## Detailed Implementation Notes

### Merge Strategy Selection

```sql
-- Auto: If no conflicts, merge automatically
strategy = 'auto'

-- Manual: Wait for manual resolution even without conflicts
strategy = 'manual'

-- Custom: Use provided resolution strategy
strategy = 'custom:ours' -- Always prefer target
strategy = 'custom:theirs' -- Always prefer source
```

### Conflict Type Classification

**Schema-level conflicts:**
- `table_added` - Table exists in source but not target
- `table_removed` - Table removed from source but exists in target
- `table_modified` - Table exists in both but structure differs

**Column-level conflicts:**
- `column_added` - Column in source but not target
- `column_removed` - Column removed from source but in target
- `column_modified` - Column type, constraints, or properties differ

**Constraint conflicts:**
- `constraint_added` - New constraint in source
- `constraint_removed` - Constraint dropped from source
- `constraint_modified` - Constraint definition changed

**Index conflicts:**
- `index_added` - New index in source
- `index_removed` - Index dropped from source

### Error Handling

```
ERROR CONDITIONS:
- Source branch doesn't exist → Return error with branch name
- Target branch doesn't exist → Return error with branch name
- Merge already in progress → Return error, suggest abort or wait
- Unresolved conflicts exist → Return conflict list
- Resolution fails → Return detailed error with rollback info
- Foreign key violation → Return specific FK constraint info
- Data type incompatibility → Return type mismatch details
```

### Idempotency Implementation

```
KEY: Merge should be safe to retry

APPROACH:
1. Check if source_branch has already been merged into target_branch
2. If yes and completed successfully:
   → Return success (no-op, idempotent)
3. If yes but awaiting resolution:
   → Return current resolution state
4. If no:
   → Proceed with normal merge
```

---

## Files to Create/Modify

### New Files:
- `sql/052_merge_operations.sql` - Merge functions and tables
- `tests/test-schema-merge.sql` - Test suite

### Modified Files:
- `sql/install.sql` - Include new merge operations file
- `docs/API_Reference.md` - Document new functions
- `CHANGELOG.md` - Add v0.2 notes (at v0.2 release)

### Documentation to Create:
- `docs/guides/merge-workflow.md` - How to use merge operations

---

## Code Quality Standards

- ✅ All code follows existing style
- ✅ 100% test coverage for new functions
- ✅ Clear variable names and comments
- ✅ Error messages are developer-friendly
- ✅ Performance considered in design
- ✅ Security validated (no injection risks)

---

## Timeline Summary

```
Week 1: Design & Setup (Mar 1-7)
Week 2: Conflict Detection (Mar 8-14)
Week 3: Merge Logic (Mar 15-21)
Week 4: Resolution (Mar 22-28)
Week 5: Testing (Mar 29-Apr 4)
Week 6: Polish & Release (Apr 5-11)
Release: v0.2 (Apr 15)
```

**Total: 6 weeks to April 15 release target**

---

## Next Steps

1. **Review this plan** with stephengibson12
2. **Discuss any clarifications** or alternate approaches
3. **Create sql/052_merge_operations.sql** skeleton
4. **Begin Week 1** implementation (Mar 1)
5. **Weekly syncs** to track progress and unblock issues

---

*Plan created: February 28, 2026*
*Status: Ready to begin v0.2 implementation*
*Lead Developer: stephengibson12 (Technical Architect)*
