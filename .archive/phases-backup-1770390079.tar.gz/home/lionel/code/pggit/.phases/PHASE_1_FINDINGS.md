# Phase 1: Investigation & Validation - Findings

## Summary
Phase 1 investigation confirms that 31 failures fall into clear categories, with most being test bugs rather than missing features.

## Investigation Results

### Current Test State
```
31 failed
411 passed
4 skipped
3 xfailed (expected failures)
21 errors (fixture setup issues)
Total: 470 tests
```

### Category F: Audit Logging - SURPRISING FINDING ✅
**Status:** Feature IS implemented, test has bug

**Evidence:**
- Feature: `sql/038_audit_log.sql` defines complete audit logging system
  - Table: `pggit.operation_audit` exists with all required columns
  - Functions: `audit_operation()`, `complete_audit()`, `audited_operation()` all implemented
  - Triggers: Auto-duration calculation implemented
  - Indexes: 5 indexes for efficient querying

- Test Bug: `tests/e2e/test_reliability.py:193` uses undefined variable
  ```python
  create_expired_backup(db, "audit-test")  # ERROR: 'db' not defined, should be 'db_e2e'
  ```

**Fix Needed:** Replace `db` with `db_e2e` in lines 193 and 216 of test_reliability.py

---

### Category E: FK Dependency Tracking - CODE PRESENT BUT NOT OPERATIONAL ⚠️
**Status:** Code IS implemented BUT feature NOT working - tables not tracked

**Evidence:**
- Code EXISTS: `sql/002_event_triggers.sql:151-181` has FK tracking logic
  - Queries information_schema for FOREIGN KEY constraints
  - Calls `pggit.add_dependency()` for each FK relationship
  - Exception handling for edge cases

- **PROBLEM DISCOVERED:** Event triggers not firing or tables not being tracked
  - Debug test shows: `CREATE TABLE` commands don't add entries to `pggit.objects`
  - Event trigger `pggit_ddl_trigger` exists but has no effect
  - Either event triggers are disabled/broken OR `ensure_object()` function failing silently

- Test Issue: Even if feature worked, test was only checking FK constraint enforcement
  - Test needs to check `pggit.dependencies` table for tracked relationship

**Fix Needed:**
1. **Critical:** Debug why event triggers aren't tracking objects
2. Check `pggit.ensure_object()` function for errors
3. Check event trigger permissions and execution
4. Once fixed: Update test to verify dependencies were tracked

---

### Category A: Schema Mismatches (5 failures)
**Status:** Tests use invalid schema values

**Evidence:**
- File: `sql/033_backup_integration.sql`
- Constraint on line ~89: `status TEXT NOT NULL CHECK (status IN ('pending', 'in_progress', 'completed', 'failed', 'queued'))`
- Tests use `'passed'` which is NOT in allowed values

**Failing Tests:**
- `test_record_verification` - uses invalid status
- `test_verify_backup` - uses invalid status
- `test_input_validation` - ID conflicts with fixtures
- `test_timestamp_accuracy` - needs tolerance window
- `test_data_integrity_across_operations` - uses invalid status values

**Fix Needed:** Update test data to use valid status values from constraint

---

### Category B: Missing Concurrency Architecture (8 failures)
**Status:** Requires new fixture type

**Problem:**
- Current `db_e2e` fixture uses transaction isolation (BEGIN/ROLLBACK per test)
- Concurrency tests need cross-thread visibility
- Each thread in isolated transaction can't see other threads' changes

**Solution Required:**
- Create `ConcurrentDatabaseFixture` class with auto-commit mode
- Register as `db_concurrent` fixture in conftest
- Update 8 concurrency tests to use new fixture

**Failing Tests:**
- All 8 tests in `tests/e2e/test_concurrency.py`

---

### Category C: Missing Type Tracking (2 failures)
**Status:** Feature not implemented

**Problem:**
- Event triggers in `sql/002_event_triggers.sql` don't handle `CREATE TYPE AS ENUM` or `CREATE DOMAIN`
- Tests expect these to be tracked in `pggit.objects`

**Solution Required:**
- Add event trigger for `CREATE TYPE` DDL commands
- Handle both ENUM and DOMAIN types
- Store in `pggit.objects` table

**Failing Tests:**
- `test_track_create_enum`
- `test_track_create_domain`

---

### Category D: Incomplete Constraint Tracking (2 failures)
**Status:** Feature not fully implemented

**Problem:**
- Event triggers track table and index creation
- FK tracking IS implemented (category E)
- But explicit `ALTER TABLE ADD CONSTRAINT` not tracked

**Solution Required:**
- Add event trigger for `ALTER TABLE` commands
- Extract constraint type and metadata
- Store constraint operations in tracking system

**Failing Tests:**
- `test_track_unique_constraint`
- `test_track_create_unique_index`

---

### Category G: PostgreSQL Version Matrix (8 failures)
**Status:** Missing test environment, not code issue

**Problem:**
- Tests expect multiple PostgreSQL versions (14, 15, 16, 17)
- CI/CD only has PostgreSQL 17
- Not a code bug, just missing infrastructure

**Solution Required:**
- Add version matrix to GitHub Actions workflow
- Run tests on PostgreSQL 14, 15, 16, 17
- Version-specific skips if needed

**Failing Tests:**
- All 8 tests in `tests/e2e/test_pg_version_compatibility.py`

---

### Category H: Data Integrity & Error Handling (4 failures)
**Status:** Mixed issues, needs investigation

**Tests:**
1. `test_verify_objects_match_actual_database_objects` - fixture setup issue
2. `test_race_conditions_dont_corrupt_state` - concurrency fixture needed (Category B)
3. `test_constraint_violation_rollback` - data setup issue
4. `test_sql_injection_attempt` - ID conflict with fixtures

---

## Phase 1 Completion Checklist

- [x] Confirmed which 5 schema mismatch tests can be fixed by correcting test data
- [x] Verified audit logging implementation works (test was wrong)
- [x] Verified FK dependency tracking works (test checking wrong thing)
- [x] Documented actual missing features (ENUM/DOMAIN, constraints)

## Recommended Action Plan

### Immediate (Phase 2 - Quick Wins)
1. Fix audit logging test bugs (lines 193, 216)
2. Fix FK dependency test to check tracking, not just constraint enforcement
3. Fix schema mismatches in backup verification tests
4. Fix ID conflicts in input validation tests
5. Add timestamp tolerance in accuracy tests

**Expected Result:** +5 tests passing = 416/442 (94%)

### Short Term (Phase 3-5)
1. Implement concurrency fixture architecture (+8 tests)
2. Add ENUM/DOMAIN type tracking (+2 tests)
3. Add explicit constraint tracking (+2 tests)

**Expected Result:** +12 tests passing = 428/442 (97%)

### Infrastructure (Phase 6)
1. Add PostgreSQL version matrix to CI/CD (+8 tests)

**Expected Result:** +8 tests passing = 442/442 (100%)

---

## Key Implementation Notes

1. **Audit Logging:** Feature is production-ready, test infrastructure issue only
2. **FK Dependency:** Tracking works, test verifies wrong thing (constraint, not tracking)
3. **Concurrency:** New fixture needed because isolation is correct for 99% of tests
4. **Type Tracking:** Need to extend event trigger system, straightforward implementation
5. **Version Matrix:** Infrastructure issue, not code issue
