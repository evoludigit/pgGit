# Phase 2: Quick Wins - Schema Fixes

## Objective
Fix tests that use incorrect schema values.

## Success Criteria
- [ ] All backup verification tests use valid status values
- [ ] Input validation test uses non-conflicting IDs
- [ ] Timestamp accuracy test has appropriate tolerance
- [ ] Data integrity tests use valid constraint values
- [ ] 5 tests now passing (96% pass rate)

## TDD Cycles

### Cycle 1: Backup Verification Status Values
- **RED**: Write test that verifies status constraint allows expected values
- **GREEN**: Update `test_record_verification` to use `'completed'` not `'passed'`
- **REFACTOR**: Extract status values to constant for reusability
- **CLEANUP**: Run linter, verify no magic strings

### Cycle 2: Backup Management Status Values
- **RED**: Existing test fails with constraint violation
- **GREEN**: Update `test_verify_backup` to use valid status values
- **REFACTOR**: Share status constant from Cycle 1
- **CLEANUP**: Verify both tests pass

### Cycle 3: Input Validation ID Conflicts
- **RED**: Test fails with unique constraint violation
- **GREEN**: Change test to use ID > 5000 to avoid fixture conflicts
- **REFACTOR**: Document ID allocation strategy (fixtures: 1-1000, tests: 5000+)
- **CLEANUP**: Check for other tests with ID conflicts

### Cycle 4: Timestamp Tolerance
- **RED**: Test fails due to microsecond timing differences
- **GREEN**: Add 1-second tolerance window to timestamp assertions
- **REFACTOR**: Extract tolerance constant
- **CLEANUP**: Verify test is stable across multiple runs

### Cycle 5: Data Integrity Constraint Values
- **RED**: Test fails with constraint violations
- **GREEN**: Update test data to use valid constraint values
- **REFACTOR**: Simplify test setup
- **CLEANUP**: Verify data setup is minimal and clear

## Dependencies
- Requires: Phase 1 complete (know which values are valid)
- Blocks: Phase 3 (reduces noise for concurrency work)

## Status
[ ] Not Started | [ ] In Progress | [ ] Complete
